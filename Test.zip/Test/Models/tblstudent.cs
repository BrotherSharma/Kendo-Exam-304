using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Test.Models
{
    public class tblstudent
    {
        public int c_id { get; set; }
        public string c_fname { get; set; }
        public string c_lname { get; set; }
        public string c_gender{get;set;}
        public string c_photo{get;set;}
        public IFormFile photo{get;set;}
        public string c_feild{get;set;}
        public string c_mobile{get;set;}
        public string c_email{get;set;}
        public string c_password{get;set;}
    }
}