using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Test.Models;
using Test.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace Test.Controllers
{
    //[Route("[controller]")]
    public class LoginController : Controller
    {
        private readonly ILogger<LoginController> _logger;

        public readonly ILoginRepository _repo;

          public LoginController(ILogger<LoginController> logger, ILoginRepository repo)
        {
            _logger = logger;
            _repo = repo;
        }


        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(tbllogin login)
        {
            bool islogin = _repo.Login(login);
           
            // if(islogin)
            // {
            //     if(login.c_email == "bhargavsharma1212@gmail.com"){
            //         return RedirectToAction("Index","Home");
            //     }
            //     else{
            //         return RedirectToAction("Privacy","Home");
            //     }
            // }
            // else{
            //     ViewBag.ErrorMessage = "Invalid username or password";
            //     return RedirectToAction("Login");
            // }
            return Ok();


        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}