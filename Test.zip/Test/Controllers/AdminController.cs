using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Test.Models;
using Test.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Npgsql;
namespace Test.Controllers
{
   // [Route("[controller]")]
    public class AdminController : Controller
    {
        private readonly ILogger<AdminController> _logger;
        private readonly IAdminRepository _repo;

        public AdminController(ILogger<AdminController> logger, IAdminRepository repo)
        {
            _logger = logger;
            _repo = repo;
        }

       [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult GetAll()
        {
            var result = _repo.GetAll();
            return Json(result);
        }
        
        [HttpGet]
        public IActionResult GetDep()
        {
            var data =_repo.GetAllCategory();
            return Json(data);
        }
        [HttpPost]
        public IActionResult Add(tbladmin model)
        {
      
            _repo.Insert(model);
            return Json(new { success = true});  
        }
         [HttpPost]
        public IActionResult Update(tbladmin kendo)
        {
          
            _repo.Update(kendo);
            return Json(new { success = true });
        }
         public IActionResult Delete(int id)
        {
            _repo.Delete(id);
            return Json(new { success = true });
        }
        [HttpGet]
        public IActionResult Student()
        {
            return View();
        }
        [HttpGet]
        public IActionResult GetAllStudent()
        {
            var result = _repo.GetAllStudent();
            return Json(result);
        }





        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}