using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Test.Models;
using Npgsql;

namespace Test.Repositories
{
    public class LoginRepository : ILoginRepository
    {
        public readonly NpgsqlConnection _conn;
        public LoginRepository(NpgsqlConnection conn)
        {
            _conn=conn;
        }


        public bool Login(tbllogin login)
        {
            var isAuthenticate = false;
            _conn.Open();
            using var command = new NpgsqlCommand("SELECT COUNT(*) FROM t_login WHERE c_email = @Email AND c_password = @password;",_conn);
            command.CommandType= CommandType.Text;
            command.Parameters.AddWithValue("@Email",login.c_email);
            command.Parameters.AddWithValue("@password",login.c_password);
            int count = Convert.ToInt32(command.ExecuteScalar());
             if(count > 0)
             {
                isAuthenticate = true;
             }
             _conn.Close();
            return isAuthenticate;
        }

    }
}