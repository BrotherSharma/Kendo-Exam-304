using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Test.Models;
using Npgsql;


namespace Test.Repositories
{
    public class AdminRepository : IAdminRepository
    {
        private readonly NpgsqlConnection _conn;
        public AdminRepository(NpgsqlConnection conn)
        {
            _conn = conn;
        }
        public List<tbladmin> GetAll()
         {
            List<tbladmin> result = new List<tbladmin>();
            _conn.Open();
            using NpgsqlCommand command =  new NpgsqlCommand("SELECT * FROM t_admin",_conn);
           using(var dr = command.ExecuteReader())
            {
                while(dr.Read())
                {
                    var data = new tbladmin()
                    {
                        c_id = Convert.ToInt32(dr["c_id"]),
                        c_category = dr["c_category"].ToString(),
                        c_bookname = dr["c_bookname"].ToString(),
                        c_initialstock = Convert.ToInt32(dr["c_initialstock"]),
                        c_availablestock = Convert.ToInt32(dr["c_availablestock"]),
                        c_date = dr.GetFieldValue<DateTime>("c_date"),
                       
                    };
                    result.Add(data);
                }
            }
            _conn.Close();
            return result;
         }


         public List<tblcategory> GetAllCategory()
        {
            var product = new List<tblcategory>();
            _conn.Open();
            using var command = new NpgsqlCommand("SELECT * FROM t_category ",_conn);
            command.CommandType = CommandType.Text;
            var reader = command.ExecuteReader();
            while(reader.Read())
            {
                var tblcategory = new tblcategory();
                {
                    tblcategory.c_id=Convert.ToInt32(reader["c_id"]);
                    tblcategory.c_category= reader["c_category"].ToString();
                   
                }
                product.Add(tblcategory);
            }
            _conn.Close();
            return product;
        }
         public void Insert(tbladmin tbladmin)
         {
            try
            {
                _conn.Open();
            using var command = new NpgsqlCommand("INSERT INTO t_admin(c_category,c_bookname,c_initialstock,c_availablestock,c_date) VALUES (@c_category,@c_bookname,@c_initialstock,@c_availablestock,@c_date)",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@c_category",tbladmin.c_category);
            command.Parameters.AddWithValue("@c_bookname",tbladmin.c_bookname);
            command.Parameters.AddWithValue("@c_initialstock",tbladmin.c_initialstock);
            command.Parameters.AddWithValue("@c_availablestock",tbladmin.c_availablestock);
            command.Parameters.AddWithValue("@c_date",tbladmin.c_date);
            command.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally{
                _conn.Close();
            }
           
         }
         public void Update(tbladmin tbladmin)
         {
            try{
                 _conn.Open();
            using var command = new NpgsqlCommand("UPDATE t_admin SET c_category=@c_category,c_bookname=@c_bookname,c_initialstock=@c_initialstock,c_availablestock = @c_availablestock,c_date = @c_date  WHERE c_id=@c_id",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@c_category",tbladmin.c_category);
            command.Parameters.AddWithValue("@c_bookname",tbladmin.c_bookname);
            command.Parameters.AddWithValue("@c_id",tbladmin.c_id);
            command.Parameters.AddWithValue("@c_initialstock",tbladmin.c_initialstock);
            command.Parameters.AddWithValue("@c_availablestock",tbladmin.c_availablestock);
            command.Parameters.AddWithValue("@c_date",tbladmin.c_date);
            command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            finally{
                _conn.Close();
            }
            _conn.Close();
         }
         public void Delete(int id)
         {
            _conn.Open();
            using var command = new NpgsqlCommand("DELETE FROM t_admin WHERE c_id=@c_id",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@c_id",id);
            command.ExecuteNonQuery();
            _conn.Close();
         }

         public List<tblstudent> GetAllStudent()
         {
            List<tblstudent> result = new List<tblstudent>();
            _conn.Open();
            using NpgsqlCommand command =  new NpgsqlCommand("SELECT * FROM t_student",_conn);
           using(var dr = command.ExecuteReader())
            {
                while(dr.Read())
                {
                    var data = new tblstudent()
                    {
                        c_id = Convert.ToInt32(dr["c_id"]),
                        c_fname = dr["c_fname"].ToString(),
                        c_lname = dr["c_lname"].ToString(),
                        c_gender = dr["c_gender"].ToString(),
                        c_photo = dr["c_photo"].ToString(),
                        c_feild = dr["c_feild"].ToString(),
                        c_email = dr["c_email"].ToString(),
                        c_mobile = dr["c_mobile"].ToString(),
                        c_password = dr["c_password"].ToString()
                        
                       
                    };
                    result.Add(data);
                }
            }
            _conn.Close();
            return result;
         }
          public List<tblfeild> GetAllFeild()
        {
            var product = new List<tblfeild>();
            _conn.Open();
            using var command = new NpgsqlCommand("SELECT * FROM t_feild ",_conn);
            command.CommandType = CommandType.Text;
            var reader = command.ExecuteReader();
            while(reader.Read())
            {
                var tblfeild = new tblfeild();
                {
                    tblfeild.c_id=Convert.ToInt32(reader["c_id"]);
                    tblfeild.c_feild= reader["c_feild"].ToString();
                   
                }
                product.Add(tblfeild);
            }
            _conn.Close();
            return product;
        }




    }
}